import sqlite3
import sys
from PyQt6.QtWidgets import QMainWindow, QApplication, QTableView, QVBoxLayout, QSizePolicy
from PyQt6.QtSql import QSqlDatabase, QSqlQueryModel
from PyQt6.QtSql import QSqlDatabase
from PyQt6.QtWidgets import QApplication, QWidget, QMainWindow
from PyQt6.QtSql import QSqlTableModel
from welcome_page import Ui_welcome_page
from employee_page import Ui_employee_page
from guest_page import Ui_guest_page
from employee_edit_page import Ui_employee_edit_page
from Guest_reserve_page import Ui_Guest_reserve_page
from untitled import Ui_clients
import sqlite3

# Создание базы данных и подключение к ней
conn = sqlite3.connect('tour.db')
cur = conn.cursor()

# Выполнение запроса SQL для создания таблицы
cur.execute('''
    CREATE TABLE IF NOT EXISTS tour (
        ID INTEGER PRIMARY KEY AUTOINCREMENT,
        Name TEXT,
        Otkuda TEXT,
        WhereTo TEXT,
        Price REAL,
        StartDate DATE,
        EndDate DATE
    )
''')

cur.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        ID INTEGER PRIMARY KEY AUTOINCREMENT,
        Name TEXT,
        Tourname TEXT,
        Passnuber TEXT
    )
''')
# Функция для добавления строки в базу данных
def add_tour(name, otkuda, where_to, price, start_date, end_date):
    cur.execute('''
        INSERT INTO tour (Name, Otkuda, WhereTo, Price, StartDate, EndDate)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (name, otkuda, where_to, price, start_date, end_date))
    conn.commit()

# Функция для удаления строки из базы данных по ID
def delete_tour(id):
    cur.execute('''
        DELETE FROM tour
        WHERE ID=?
    ''', (id,))
    conn.commit()

# Функция для изменения строки в базе данных
def update_tour(id, name, otkuda, where_to, price, start_date, end_date):
    cur.execute('''
        UPDATE tour
        SET Name=?, Otkuda=?, WhereTo=?, Price=?, StartDate=?, EndDate=?
        WHERE ID=?
    ''', (name, otkuda, where_to, price, start_date, end_date, id))
    conn.commit()

# Закрытие соединения с базой данных
    
    

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_welcome_page()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.openEmployeePage)
        self.ui.pushButton_2.clicked.connect(self.openGuestPage)
        
        
    def openEmployeePage(self):
        self.newWindow = EmployeePage()
        self.newWindow.show()

    def openGuestPage(self):
        self.newWindow = GuestPage()
        self.newWindow.show()
        
class EmployeePage(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_employee_page()
        self.ui.setupUi(self)
        db = QSqlDatabase.addDatabase('QSQLITE')
        db.setDatabaseName('tour.db')

        if not db.open():
            print("Ошибка при открытии базы данных")

        self.table_view = QTableView()
        self.model = QSqlQueryModel()
        
        # Загружаем данные из таблицы tours
        self.model.setQuery("SELECT * FROM tours", db)
        

        self.table_view.setModel(self.model)

        layout = QVBoxLayout()
        layout.addWidget(self.table_view)

        widget = QWidget()
        widget.setLayout(layout)

    

        

       
        self.show()
        def viewData(self):
            self.model = QSqlTableModel(self)
            self.model.setTable('tour')
            self.model.select()
            self.ui.tableView.setModel(self.model)
        
        
        self.ui.pushButton_3.clicked.connect(self.openEmployeeUpdatePage)
        self.ui.pushButton.clicked.connect(self.openEmployeeAddPage)
        self.ui.pushButton_2.clicked.connect(self.deleteTour)
        self.ui.pushButton_4.clicked.connect(self.clients)

        
        
        self.viewData()
    def clients(self):
        self.newWindow = clientsPAge()
        self.newWindow.show()
    def viewData(self):
        self.model = QSqlTableModel(self)
        self.model.setTable('tour')
        self.model.select()
        self.ui.tableView.setModel(self.model)

    def openEmployeeAddPage(self):
        self.newWindow = EmployeeAddPage()
        self.newWindow.show()

    def openEmployeeUpdatePage(self):
        self.newWindow = EmployeeUpdatePage()
        self.newWindow.show()
        
    
    def deleteTour(self):
        index = self.ui.tableView.selectedIndexes()[0]
        id = str(self.ui.tableView.model().data(index))
        print(id)
        delete_tour(id)
       
        
class clientsPAge(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_clients()
        self.ui.setupUi(self)
        db = QSqlDatabase.addDatabase('QSQLITE')
        db.setDatabaseName('tour.db')

        if not db.open():
            print("Ошибка при открытии базы данных")

        self.table_view = QTableView()
        self.model = QSqlQueryModel()
        
        # Загружаем данные из таблицы tours
        self.model.setQuery("SELECT * FROM orders", db)
        

        self.table_view.setModel(self.model)

        layout = QVBoxLayout()
        layout.addWidget(self.table_view)

        widget = QWidget()
        widget.setLayout(layout)

        self.viewData()
    def viewData(self):
        self.model = QSqlTableModel(self)
        self.model.setTable('orders')
        self.model.select()
        self.ui.tableView_3.setModel(self.model)
        self.show()
        

       
        self.show()
class EmployeeAddPage(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_employee_edit_page()
        self.ui.setupUi(self)

        db = QSqlDatabase.addDatabase('QSQLITE')
        db.setDatabaseName('tour.db')

        if not db.open():
            print("Ошибка при открытии базы данных")

        self.table_view = QTableView()
        self.model = QSqlQueryModel()
        
        # Загружаем данные из таблицы tours
        self.model.setQuery("SELECT * FROM tour", db)
        

        self.table_view.setModel(self.model)

        layout = QVBoxLayout()
        layout.addWidget(self.table_view)

        widget = QWidget()
        widget.setLayout(layout)

    

        

       
        self.show()
        
        
        self.ui.pushButton.clicked.connect(self.addNewTour)
        
        

        
    def addNewTour(self):
        name = self.ui.lineEdit.text()#Name, Kuda, Where, Price, StartDate, EndDate
        otkuda = self.ui.lineEdit_3.text()
        where = self.ui.lineEdit_2.text()
        price = self.ui.lineEdit_4.text()
        startdate = self.ui.dateTimeEdit.text()
        enddate = self.ui.dateTimeEdit_2.text()
       
        add_tour(name, otkuda, where, price, startdate, enddate)
        
class EmployeeUpdatePage(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_employee_edit_page()
        self.ui.setupUi(self)
        
        
        self.ui.pushButton.clicked.connect(self.UpdateTour)
        
        

        
    def UpdateTour(self, id):
       

        name = self.ui.lineEdit.text()#Name, Kuda, Where, Price, StartDate, EndDate
        otkuda = self.ui.lineEdit_3.text()
        where = self.ui.lineEdit_2.text()
        price = self.ui.lineEdit_4.text()
        startdate = self.ui.dateTimeEdit.text()
        enddate = self.ui.dateTimeEdit_2.text()

        update_tour(id, name, otkuda, where, price, startdate, enddate)
        
      
       
       
   
class GuestPage(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_guest_page()
        self.ui.setupUi(self)
        self.ui.pushButton_3.clicked.connect(self.openGuestReservePage)
        self.viewData()
        db = QSqlDatabase.addDatabase('QSQLITE')
        db.setDatabaseName('tour.db')

        if not db.open():
            print("Ошибка при открытии базы данных")

        self.table_view = QTableView()
        self.model = QSqlQueryModel()
        
        # Загружаем данные из таблицы tours
        self.model.setQuery("SELECT * FROM tour", db)
        

        self.table_view.setModel(self.model)

        layout = QVBoxLayout()
        layout.addWidget(self.table_view)

        widget = QWidget()
        widget.setLayout(layout)
    def openGuestReservePage(self):
        self.newWindow = GuestReservePage()
        self.newWindow.show()
    def viewData(self):
        self.model = QSqlTableModel(self)
        self.model.setTable('tour')
        self.model.select()
        self.ui.tableView_2.setModel(self.model)
        self.show()

class GuestReservePage(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Guest_reserve_page()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.reserve)
    def reserve(self):
        name = self.ui.lineEdit_5.text()#Name, Kuda, Where, Price, StartDate, EndDate
        tourname = self.ui.lineEdit_6.text()
        passportnumber = self.ui.lineEdit.text()
        print(name, tourname, passportnumber)
        cur.execute('''
        INSERT INTO orders (Name, Tourname, Passnuber)  VALUES (?, ?, ?)
    ''', (name, tourname, passportnumber))
        conn.commit()
        file = open("123.txt", "w")
        file.write(f"ФИО: {name}, Название тура: {tourname}, Пасспорт: {passportnumber}")
        file.close()


    
            
def main():
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()