from PyQt6 import QtWidgets, QtSql
import random


class Data:
    def __init__(self):
        super(Data, self).__init__()
        self.create_connection()

    def create_connection(self):
        db = QtSql.QSqlDatabase.addDatabase('QSQLITE')
        db.setDatabaseName('expense_db.db')

        if not self.db.open():
            QtWidgets.QMessageBox.critical(None, "Cannot open database",
                                           "Click Cancel to exit.", QtWidgets.QMessageBox.Cancel)
            return False

        query = QtSql.QSqlQuery()
        query.exec("CREATE TABLE IF NOT EXISTS tour (ID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Otkuda TEXT, Where TEXT, Price REAL, StartDate DATE, EndDate DATE")
        return True

    def execute_query_with_params(self, sql_query, query_values=None):
        query = QtSql.QSqlQuery()
        query.prepare(sql_query)

        if query_values is not None:
            for query_value in query_values:
                query.addBindValue(query_value)

        query.exec()

        return query

    def add_new_tour(self, name, otkuda, where, price, startdate, enddate):
        sql_query = "INSERT INTO tour (Name, Otkuda, Where, Price, StartDate, EndDate) VALUES (?, ?, ?, ?, ?, ?)"
        self.execute_query_with_params(sql_query, [name, otkuda, where, price, startdate, enddate])

    def update_tour(self, name, otkuda, where, price, startdate, enddate):
        sql_query = "UPDATE tour SET Name=?, Otkuda=?, Where=?, Price=?, StartDate=?,EndDate=?  WHERE ID=?"
        self.execute_query_with_params(sql_query, [name, otkuda, where, price, startdate, enddate, id])

    def delete_tour(self, id):
        sql_query = "DELETE FROM tour WHERE ID=?"
        self.execute_query_with_params(sql_query, [id])

    def get_tour(self, column, filter=None, value=None):
        sql_query = f"SELECT SUM({column}) FROM expenses"

        if filter is not None and value is not None:
            sql_query += f" WHERE {filter} = ?"

        query_values = []

        if value is not None:
            query_values.append(value)

        query = self.execute_query_with_params(sql_query, query_values)

        if query.next():
            return str(query.value(0)) + '$'

        return '0'
    def total_balance(self):
        return self.get_total(column="Balance")

    